import SwiftUI
import VisionKit
import AVFoundation
import Vision

struct ScannerView: View {
    @EnvironmentObject var apiService: APIService
    let session: ScanSession
    let onEnd: () -> Void
    
    @State private var isScanning = false  // Pausado por defecto
    @State private var detectedText: String = ""
    @State private var capturedArticles: [(article: String, quantity: String, sent: Bool, status: String?, description: String?, partNumber: String?)] = []  // Artículos con estado
    @State private var scannedItems: [ScanRecord] = []
    @State private var showManualEntry = false
    @State private var showConfirmMultipleScan = false  // Para confirmar múltiples scans
    @State private var manualSAP = ""
    @State private var manualPO = ""
    @State private var errorMessage: String?
    @State private var successMessage: String?
    @State private var detectedCount: Int = 0  // Cantidad de números detectados
    
    var body: some View {
        NavigationView {
            ZStack {
                // Live Text Scanner
                LiveTextScannerView(
                    recognizedText: $detectedText,
                    onTextDetected: handleTextDetected
                )
                .ignoresSafeArea()
                .opacity(isScanning ? 1.0 : 0.5)
                
                // Scan Region Overlay
                VStack {
                    Spacer()
                    
                    Rectangle()
                        .fill(Color.clear)
                        .frame(height: 150)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(isScanning ? Color.green : Color.gray, lineWidth: 3)
                        )
                        .padding(.horizontal, 40)
                    
                    Spacer()
                }
                
                // Camera Status Overlay
                if !isScanning {
                    VStack {
                        Spacer()
                        Text("Camera Paused")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.black.opacity(0.7))
                            .cornerRadius(8)
                        Spacer()
                        Spacer()
                        Spacer()
                    }
                }
                
                // Bottom Info Panel
                VStack {
                    Spacer()
                    
                    VStack(spacing: 16) {
                        // Session Info
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(session.category.displayName)
                                    .font(.headline)
                                Text("\(session.mode.displayName) Mode")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Text("\(scannedItems.count) scanned")
                                .font(.headline)
                                .foregroundColor(.blue)
                        }
                        
                        // Last detected text
                        if detectedCount > 0 {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                Text("\(detectedCount) article\(detectedCount > 1 ? "s" : "") detected")
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                            }
                            .padding(8)
                            .background(Color.green.opacity(0.1))
                            .cornerRadius(8)
                        } else if isScanning {
                            VStack(spacing: 4) {
                                Text("Scanning...")
                                    .font(.caption)
                                    .foregroundColor(.orange)
                                if !detectedText.isEmpty {
                                    Text("OCR: \(detectedText.prefix(50))...")
                                        .font(.system(size: 8))
                                        .foregroundColor(.secondary)
                                        .lineLimit(1)
                                }
                            }
                        }
                        
                        // Messages
                        if let error = errorMessage {
                            Text(error)
                                .font(.caption)
                                .foregroundColor(.red)
                                .multilineTextAlignment(.center)
                        }
                        
                        if let success = successMessage {
                            Text(success)
                                .font(.caption)
                                .foregroundColor(.green)
                                .multilineTextAlignment(.center)
                        }
                        
                        // Action Buttons
                        VStack(spacing: 12) {
                            // Botón principal de captura
                            Button(action: captureAndConfirm) {
                                HStack {
                                    Image(systemName: detectedCount > 1 ? "square.stack.3d.up.fill" : "camera.viewfinder")
                                        .font(.title2)
                                    if detectedCount > 0 {
                                        Text("Capture \(detectedCount) Article\(detectedCount > 1 ? "s" : "")")
                                            .font(.headline)
                                    } else {
                                        Text("Capture Scan")
                                            .font(.headline)
                                    }
                                }
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(detectedCount > 0 ? Color.green : Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(12)
                            }
                            .disabled(detectedCount == 0)
                            
                            HStack(spacing: 16) {
                                Button(action: { showManualEntry = true }) {
                                    Label("Manual", systemImage: "keyboard")
                                        .font(.caption)
                                }
                                .buttonStyle(.bordered)
                                
                                Button(action: toggleScanning) {
                                    Label(isScanning ? "Stop Camera" : "Start Camera", systemImage: isScanning ? "pause.circle.fill" : "play.circle.fill")
                                        .font(.caption)
                                }
                                .buttonStyle(.bordered)
                                
                                Button(action: endSession) {
                                    Label("End", systemImage: "stop.circle.fill")
                                        .font(.caption)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(.red)
                            }
                        }
                    }
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(16)
                    .padding()
                }
            }
            .navigationTitle("Scanning")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showManualEntry) {
                ManualEntryView(
                    sapArticle: $manualSAP,
                    poNumber: $manualPO,
                    onSubmit: handleManualEntry
                )
            }
            .sheet(isPresented: $showConfirmMultipleScan) {
                ConfirmMultipleScanView(
                    articles: $capturedArticles,
                    onSendIndividual: sendIndividualArticle,
                    onDone: confirmMultipleScan,
                    onCancel: { 
                        showConfirmMultipleScan = false
                        isScanning = true  // Reanudar cámara
                    }
                )
            }
        }
    }
    
    private func toggleScanning() {
        isScanning.toggle()
    }
    
    private func handleTextDetected(_ text: String) {
        guard isScanning else { return }
        
        detectedText = text
        
        // Detectar MÚLTIPLES números de 9-10 dígitos (más flexible)
        let sapPattern = #"\b[0-9]{9,10}\b"#
        var detectedArticles: [String] = []
        
        if let regex = try? NSRegularExpression(pattern: sapPattern) {
            let matches = regex.matches(in: text, range: NSRange(text.startIndex..., in: text))
            
            for match in matches.prefix(5) {  // Límite de 5 artículos por captura
                if let range = Range(match.range, in: text) {
                    let article = String(text[range])
                    // Solo artículos únicos y de exactamente 10 dígitos preferidos
                    if !detectedArticles.contains(article) {
                        detectedArticles.append(article)
                    }
                }
            }
        }
        
        // Actualizar el contador solo si cambió
        DispatchQueue.main.async {
            self.detectedCount = detectedArticles.count
        }
    }
    
    private func captureAndConfirm() {
        guard !detectedText.isEmpty else {
            errorMessage = "No text detected. Start camera and point at list."
            return
        }
        
        // Extraer TODOS los números de 9-10 dígitos
        let sapPattern = #"\b[0-9]{9,10}\b"#
        var articles: [String] = []
        
        if let regex = try? NSRegularExpression(pattern: sapPattern) {
            let matches = regex.matches(in: detectedText, range: NSRange(detectedText.startIndex..., in: detectedText))
            
            for match in matches.prefix(5) {  // Max 5 artículos
                if let range = Range(match.range, in: detectedText) {
                    let article = String(detectedText[range])
                    if !articles.contains(article) && article.count == 10 {  // Preferir 10 dígitos
                        articles.append(article)
                    }
                }
            }
            
            // Si no hay de 10, aceptar de 9
            if articles.isEmpty {
                for match in matches.prefix(5) {
                    if let range = Range(match.range, in: detectedText) {
                        let article = String(detectedText[range])
                        if !articles.contains(article) {
                            articles.append(article)
                        }
                    }
                }
            }
        }
        
        guard !articles.isEmpty else {
            errorMessage = "No valid SAP article numbers detected (9-10 digits)"
            return
        }
        
        // Convertir a tuplas con cantidad inicial = "1" y sin enviar
        capturedArticles = articles.map { (article: $0, quantity: "1", sent: false, status: nil, description: nil, partNumber: nil) }
        showConfirmMultipleScan = true
        isScanning = false  // Pausa cámara mientras confirma
    }
    
    private func sendIndividualArticle(at index: Int) {
        guard index < capturedArticles.count else { return }
        let item = capturedArticles[index]
        
        guard !item.sent, let quantity = Double(item.quantity), quantity > 0 else { return }
        
        Task {
            do {
                print("📦 Sending individual: \(item.article) x\(quantity)")
                
                let record = try await apiService.sendScan(
                    sessionId: session.id,
                    sapArticle: item.article,
                    poNumber: nil,
                    quantity: quantity
                )
                
                scannedItems.append(record)
                
                // Actualizar el estado del artículo
                capturedArticles[index].sent = true
                capturedArticles[index].status = record.status
                capturedArticles[index].description = record.description
                capturedArticles[index].partNumber = record.partNumber
                
                print("✅ Success: \(record.sapArticle) - Status: \(record.status)")
                
            } catch {
                errorMessage = "Failed: \(error.localizedDescription)"
                print("❌ Error: \(error)")
            }
        }
    }
    
    private func confirmMultipleScan() {
        // Cerrar el diálogo (todos los artículos ya fueron enviados individualmente)
        showConfirmMultipleScan = false
        capturedArticles = []
        detectedCount = 0
    }
    
    private func handleManualEntry() {
        guard !manualSAP.isEmpty else { return }
        
        sendScan(sapArticle: manualSAP, poNumber: manualPO.isEmpty ? nil : manualPO)
        manualSAP = ""
        manualPO = ""
        showManualEntry = false
    }
    
    private func sendScan(sapArticle: String, poNumber: String?, quantity: Double = 1.0) {
        Task {
            do {
                let record = try await apiService.sendScan(
                    sessionId: session.id,
                    sapArticle: sapArticle,
                    poNumber: poNumber,
                    quantity: quantity
                )
                
                scannedItems.append(record)
                successMessage = "✓ \(sapArticle) x\(quantity) scanned"
                errorMessage = nil
                
                // Clear success message after 2 seconds
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    successMessage = nil
                }
                
            } catch {
                errorMessage = "Failed: \(error.localizedDescription)"
                successMessage = nil
            }
        }
    }
    
    private func endSession() {
        Task {
            do {
                try await apiService.endSession(id: session.id)
                onEnd()
            } catch {
                errorMessage = "Failed to end session: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - Live Text Scanner (Using VisionKit)
struct LiveTextScannerView: UIViewControllerRepresentable {
    @Binding var recognizedText: String
    let onTextDetected: (String) -> Void
    
    func makeUIViewController(context: Context) -> LiveTextViewController {
        let controller = LiveTextViewController()
        controller.delegate = context.coordinator
        return controller
    }
    
    func updateUIViewController(_ uiViewController: LiveTextViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, LiveTextDelegate {
        let parent: LiveTextScannerView
        
        init(_ parent: LiveTextScannerView) {
            self.parent = parent
        }
        
        func didRecognizeText(_ text: String) {
            DispatchQueue.main.async {
                self.parent.recognizedText = text
                self.parent.onTextDetected(text)
            }
        }
    }
}

// MARK: - Live Text View Controller
protocol LiveTextDelegate: AnyObject {
    func didRecognizeText(_ text: String)
}

class LiveTextViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    weak var delegate: LiveTextDelegate?
    
    private var captureSession: AVCaptureSession!
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private let textRecognitionRequest = VNRecognizeTextRequest()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
    }
    
    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .high
        
        guard let videoCaptureDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let videoInput = try? AVCaptureDeviceInput(device: videoCaptureDevice),
              captureSession.canAddInput(videoInput) else {
            return
        }
        
        captureSession.addInput(videoInput)
        
        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        
        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        }
        
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = view.bounds
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.captureSession.startRunning()
        }
    }
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        let requestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        
        do {
            try requestHandler.perform([textRecognitionRequest])
            
            if let results = textRecognitionRequest.results as? [VNRecognizedTextObservation] {
                let text = results.compactMap { observation in
                    observation.topCandidates(1).first?.string
                }.joined(separator: " ")
                
                if !text.isEmpty {
                    delegate?.didRecognizeText(text)
                }
            }
        } catch {
            print("Error performing text recognition: \(error)")
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.bounds
    }
}

// MARK: - Confirm Multiple Scan View
struct ConfirmMultipleScanView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var articles: [(article: String, quantity: String, sent: Bool, status: String?, description: String?, partNumber: String?)]
    let onSendIndividual: (Int) -> Void
    let onDone: () -> Void
    let onCancel: () -> Void
    
    private var allSent: Bool {
        articles.allSatisfy { $0.sent }
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 8) {
                    Image(systemName: "list.bullet.clipboard")
                        .font(.system(size: 50))
                        .foregroundColor(.blue)
                    Text("Send One by One")
                        .font(.title2)
                        .fontWeight(.bold)
                    Text("\(articles.filter { $0.sent }.count)/\(articles.count) sent")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .padding()
                
                Divider()
                
                // Lista de artículos
                ScrollView {
                    VStack(spacing: 12) {
                        ForEach(Array(articles.indices), id: \.self) { index in
                            ArticleRowView(
                                index: index,
                                item: $articles[index],
                                onSend: { onSendIndividual(index) }
                            )
                        }
                    }
                    .padding()
                }
                
                // Botón Done
                VStack(spacing: 12) {
                    if allSent {
                        Button(action: {
                            onDone()
                            dismiss()
                        }) {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                Text("Done")
                                    .fontWeight(.semibold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                        }
                    }
                    
                    Button(action: {
                        onCancel()
                        dismiss()
                    }) {
                        Text(allSent ? "Close" : "Cancel")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(.systemGray5))
                            .foregroundColor(.primary)
                            .cornerRadius(12)
                    }
                }
                .padding()
            }
            .navigationTitle("Review & Send")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - Article Row View
struct ArticleRowView: View {
    let index: Int
    @Binding var item: (article: String, quantity: String, sent: Bool, status: String?, description: String?, partNumber: String?)
    let onSend: () -> Void
    
    private var statusColor: Color {
        guard let status = item.status else { return .gray }
        switch status.uppercased() {
        case "MATCH": return .green
        case "OVER": return .orange
        case "UNDER": return .red
        default: return .gray
        }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                // Número
                Text("\(index + 1)")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 32, height: 32)
                    .background(item.sent ? Color.green : Color.blue)
                    .clipShape(Circle())
                
                // Info del artículo
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.article)
                        .font(.system(.body, design: .monospaced))
                        .fontWeight(.semibold)
                    
                    if item.sent, let partNumber = item.partNumber {
                        Text("PN: \(partNumber)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    if item.sent, let description = item.description {
                        Text(description)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .lineLimit(2)
                    }
                }
                
                Spacer()
                
                if !item.sent {
                    // Controles de cantidad
                    HStack(spacing: 4) {
                        Button(action: decreaseQuantity) {
                            Image(systemName: "minus.circle.fill")
                                .foregroundColor(.red)
                                .font(.title3)
                        }
                        
                        TextField("Qty", text: $item.quantity)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.center)
                            .frame(width: 45)
                            .textFieldStyle(.roundedBorder)
                        
                        Button(action: increaseQuantity) {
                            Image(systemName: "plus.circle.fill")
                                .foregroundColor(.green)
                                .font(.title3)
                        }
                    }
                    
                    // Botón enviar
                    Button(action: onSend) {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.title)
                            .foregroundColor(.blue)
                    }
                } else {
                    // Status badge
                    if let status = item.status {
                        HStack(spacing: 4) {
                            Image(systemName: status.uppercased() == "MATCH" ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                            Text(status.uppercased())
                                .fontWeight(.bold)
                        }
                        .font(.caption)
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(statusColor)
                        .cornerRadius(12)
                    }
                    
                    Image(systemName: "checkmark.circle.fill")
                        .font(.title)
                        .foregroundColor(.green)
                }
            }
            .padding()
            .background(item.sent ? Color.green.opacity(0.1) : Color(.systemGray6))
            .cornerRadius(12)
        }
    }
    
    private func increaseQuantity() {
        if let current = Double(item.quantity) {
            item.quantity = String(format: "%.0f", current + 1)
        }
    }
    
    private func decreaseQuantity() {
        if let current = Double(item.quantity), current > 1 {
            item.quantity = String(format: "%.0f", current - 1)
        }
    }
}

// MARK: - Manual Entry View
struct ManualEntryView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var sapArticle: String
    @Binding var poNumber: String
    let onSubmit: () -> Void
    
    var body: some View {
        NavigationView {
            Form {
                Section("Article Information") {
                    TextField("SAP Article *", text: $sapArticle)
                        .keyboardType(.numbersAndPunctuation)
                    
                    TextField("PO Number (optional)", text: $poNumber)
                        .keyboardType(.numbersAndPunctuation)
                }
            }
            .navigationTitle("Manual Entry")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Submit") {
                        onSubmit()
                        dismiss()
                    }
                    .disabled(sapArticle.isEmpty)
                }
            }
        }
    }
}

#Preview {
    ScannerView(
        session: ScanSession(
            id: 1,
            userId: 1,
            mode: .inventory,
            category: .cctv,
            bomId: nil,
            startedAt: "2024-01-01T00:00:00",
            endedAt: nil,
            isActive: true
        ),
        onEnd: {}
    )
    .environmentObject(APIService())
}
