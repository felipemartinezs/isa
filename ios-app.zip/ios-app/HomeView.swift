import SwiftUI

struct HomeView: View {
    @EnvironmentObject var apiService: APIService
    @State private var selectedCategory: Category = .cctv
    @State private var selectedMode: ScanMode = .inventory
    @State private var selectedBOM: BOM?
    @State private var availableBOMs: [BOM] = []
    @State private var isLoadingBOMs = false
    @State private var isCreatingSession = false
    @State private var currentSession: ScanSession?
    @State private var showScanner = false
    @State private var errorMessage: String?
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                // User Info
                if let user = apiService.currentUser {
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Welcome, \(user.username)")
                                .font(.headline)
                            Text(user.email)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        Button("Logout") {
                            apiService.logout()
                        }
                        .foregroundColor(.red)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                }
                
                // Category Selection
                VStack(alignment: .leading, spacing: 12) {
                    Text("Select Category")
                        .font(.headline)
                    
                    Picker("Category", selection: $selectedCategory) {
                        ForEach(Category.allCases, id: \.self) { category in
                            Text(category.displayName).tag(category)
                        }
                    }
                    .pickerStyle(.segmented)
                    .onChange(of: selectedCategory) { _ in
                        loadBOMs()
                    }
                }
                
                // Mode Selection
                VStack(alignment: .leading, spacing: 12) {
                    Text("Select Mode")
                        .font(.headline)
                    
                    Picker("Mode", selection: $selectedMode) {
                        ForEach(ScanMode.allCases, id: \.self) { mode in
                            Text(mode.displayName).tag(mode)
                        }
                    }
                    .pickerStyle(.segmented)
                    .onChange(of: selectedMode) { _ in
                        if selectedMode == .bom {
                            loadBOMs()
                        }
                    }
                }
                
                // BOM Selection (if BOM mode)
                if selectedMode == .bom {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Select BOM")
                            .font(.headline)
                        
                        if isLoadingBOMs {
                            ProgressView()
                                .frame(maxWidth: .infinity)
                        } else if availableBOMs.isEmpty {
                            Text("No BOMs available for \(selectedCategory.displayName)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .frame(maxWidth: .infinity, alignment: .center)
                                .padding()
                                .background(Color(.systemGray6))
                                .cornerRadius(8)
                        } else {
                            ScrollView {
                                VStack(spacing: 8) {
                                    ForEach(availableBOMs) { bom in
                                        Button(action: { selectedBOM = bom }) {
                                            HStack {
                                                VStack(alignment: .leading) {
                                                    Text(bom.name)
                                                        .font(.body)
                                                        .foregroundColor(.primary)
                                                    Text("Uploaded: \(formatDate(bom.uploadedAt))")
                                                        .font(.caption)
                                                        .foregroundColor(.secondary)
                                                }
                                                Spacer()
                                                if selectedBOM?.id == bom.id {
                                                    Image(systemName: "checkmark.circle.fill")
                                                        .foregroundColor(.blue)
                                                }
                                            }
                                            .padding()
                                            .background(selectedBOM?.id == bom.id ? Color.blue.opacity(0.1) : Color(.systemGray6))
                                            .cornerRadius(8)
                                        }
                                    }
                                }
                            }
                            .frame(maxHeight: 200)
                        }
                    }
                }
                
                Spacer()
                
                // Error Message
                if let error = errorMessage {
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                }
                
                // Start Session Button
                Button(action: startSession) {
                    if isCreatingSession {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    } else {
                        Label("Start Scanning", systemImage: "barcode.viewfinder")
                            .fontWeight(.semibold)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(canStartSession ? Color.blue : Color.gray)
                .foregroundColor(.white)
                .cornerRadius(10)
                .disabled(!canStartSession || isCreatingSession)
            }
            .padding()
            .navigationTitle("ISA Scanner")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                loadBOMs()
            }
            .fullScreenCover(isPresented: $showScanner) {
                if let session = currentSession {
                    ScannerView(session: session, onEnd: {
                        showScanner = false
                        currentSession = nil
                    })
                    .environmentObject(apiService)
                }
            }
        }
    }
    
    private var canStartSession: Bool {
        if selectedMode == .bom {
            return selectedBOM != nil
        }
        return true
    }
    
    private func loadBOMs() {
        guard selectedMode == .bom else { return }
        
        isLoadingBOMs = true
        Task {
            do {
                availableBOMs = try await apiService.getBOMs(category: selectedCategory)
                if !availableBOMs.isEmpty && selectedBOM == nil {
                    selectedBOM = availableBOMs.first
                }
            } catch {
                errorMessage = "Failed to load BOMs: \(error.localizedDescription)"
            }
            isLoadingBOMs = false
        }
    }
    
    private func startSession() {
        isCreatingSession = true
        errorMessage = nil
        
        Task {
            do {
                let session = try await apiService.createSession(
                    mode: selectedMode,
                    category: selectedCategory,
                    bomId: selectedBOM?.id
                )
                currentSession = session
                showScanner = true
            } catch {
                errorMessage = "Failed to start session: \(error.localizedDescription)"
            }
            isCreatingSession = false
        }
    }
    
    private func formatDate(_ dateString: String) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        
        guard let date = formatter.date(from: dateString) else {
            return dateString
        }
        
        let displayFormatter = DateFormatter()
        displayFormatter.dateStyle = .short
        displayFormatter.timeStyle = .short
        return displayFormatter.string(from: date)
    }
}

#Preview {
    HomeView()
        .environmentObject(APIService())
}
